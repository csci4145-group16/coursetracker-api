
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'idunnett',
  applicationName: 'coursetracker-api',
  appUid: 'DnqX0TKmFJPp5V1JsT',
  orgUid: 'fd57896b-3ab7-4e76-afe4-2d6ea5a3eb21',
  deploymentUid: '01e8c1b7-0516-4cda-93c4-7b408c6e46f2',
  serviceName: 'coursetracker-api',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'coursetracker-api-dev-api', timeout: 6 };

try {
  const userHandler = require('./dist/app.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}